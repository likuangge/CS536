Dan Wortmann
CS536 - Fall 2015

The program is ran simply by compiling P1.java

$ javac P1.java

And executing it via JRE

$ java P1

The expected output should indicate the testing has finished, as well as
a few print outs of SymTables. If the programs finishes execution successfully, the final print message is shown. I did not implement any file reading into this because I did not see it neccessary at this point, I simply tested the functionality of the Sym and SymTable classes.
